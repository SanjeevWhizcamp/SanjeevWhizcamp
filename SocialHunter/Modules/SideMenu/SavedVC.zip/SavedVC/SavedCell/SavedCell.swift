//
//  SavedCell.swift
//  SocialHunter
//
//  Created by Apple on 17/11/21.
//

import UIKit

class SavedCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    
}
